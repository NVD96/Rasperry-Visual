# Cài đặt Raspango trên Windows 10

# Bước 1: cài đặt các thư viện cần thiết

## Cài đặt Python 3.6.5

## Cài đặt Visual Studio Code

## 


# Bước 2: clone source code

# Bước 3: cài đặt các package

# Bước 4: chạy chương trình