# Raspango
Source code web server dùng để cung cấp API xử lý ảnh. Sử dụng Django chạy trên nhiều hệ điều hành như Windows, Centos, Ubuntu và Raspbian để xử lý ảnh, nhận diện vật thể và trả về cho client. Đối với Raspberry Pi còn có thêm chức năng đọc tín hiệu cảm biến, xuất tín hiệu ra các chân GPIO,...


# Cài đặt
Đối với hệ điều hành Windows, vui lòng đọc [README_windows.md](README_windows.md)

Đối với hệ điều hành Ubuntu, vui lòng đọc [README_ubuntu.md](README_ubuntu.md)

# Bài viết
https://thigiacmaytinh.com/tgmtdjango-goi-code-opencv-python-qua-web-api/