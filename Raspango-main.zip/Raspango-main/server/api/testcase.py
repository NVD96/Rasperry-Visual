#from api.test.testUser import *
from api.test.testPerson import *
#from api.test.testApi import *

personTest = PersonTest()
#personTest.FindFace()
# personTest.TestDistance()
# personTest.CountTime()
personTest.TestGender()

#apiTest = ApiTest()
#apiTest.TestAddStatsImage()