from .notfound import notfound

from .views import index, login, logout, user,\
    changepassword, \
    relayshield, \
    camera,\
    webcam,\
    facemask,\
    register,  \
    video_feed, \
    stream, \
    upload
