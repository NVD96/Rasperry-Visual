# Raspango
Source code web server dùng để cung cấp API xử lý ảnh. Sử dụng Django chạy trên nhiều hệ điều hành như Windows, Centos, Ubuntu và Raspbian để xử lý ảnh, nhận diện vật thể và trả về cho client. Đối với Raspberry Pi còn có thêm chức năng đọc tín hiệu cảm biến, xuất tín hiệu ra các chân GPIO,...


# Bước 1: cài đặt các thư viện cần thiết

sudo apt install libgl1-mesa-glx